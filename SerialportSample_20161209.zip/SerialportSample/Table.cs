﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerialportSample
{
    class Table
    {

        private string paramId;

        private string paramName;

        private int length;

        private string type1;
        private string type2;
        private string type3;

        private string value1;

        private int scale1;
        private int scale2;
        private int scale3;

        private string unit1;
        private string unit2;
        private string unit3;
    }
}
