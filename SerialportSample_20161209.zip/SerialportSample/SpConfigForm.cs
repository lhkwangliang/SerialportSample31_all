﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SerialportSample
{
    public partial class SpConfigForm : Form
    {
        public SpConfigForm()
        {
            InitializeComponent();
            //初始化下拉串口名称列表框  
            string[] ports = SerialPort.GetPortNames();
            Array.Sort(ports);
            cbPortName.Items.AddRange(ports);
            if(cbPortName.Items.Count <= 0)
            {
                cbPortName.SelectedIndex = -1;
            }else{
                if (Program.globalPortName == "")
                {
                    cbPortName.SelectedIndex = (cbPortName.Items.Count - 1);
                }
                else if (cbPortName.Text != Program.globalPortName)
                {
                    cbPortName.Text = Program.globalPortName;
                }
            }
            //cbPortName.SelectedIndex = cbPortName.Items.Count > 0 ? (? : 0) : -1;
            if (int.Parse(cbBaudrate.Text) != Program.globalBaudrate)
            {
                cbBaudrate.Text = Program.globalBaudrate.ToString();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cbPortName.Text == "")
            {
                cbPortName.Focus();
            }
            else if (int.Parse(cbBaudrate.Text) <= 0)
            {
                cbBaudrate.Focus();
            }
            else
            {
                Program.globalPortName = cbPortName.Text;
                Program.globalBaudrate = int.Parse(cbBaudrate.Text);
                this.Dispose();
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
